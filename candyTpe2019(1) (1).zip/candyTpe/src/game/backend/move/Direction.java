package game.backend.move;

public enum Direction {

	UP, DOWN, LEFT, RIGHT

}
